<?php
include("includes/header.php");

if(!isset($_SESSION["user_id"])) {
    header("Location: bejelentkezes.php");
    exit();
}
?>

<main>
    <div class="card">
        <h2>Üdv, <?php echo $_SESSION["teljes_nev"]; ?>!</h2>

        <p>Itt tudsz időpontot foglalni.</p>

        <p style="text-align: center; margin-top: 10px;">
            <a href="foglalas.php" class="booking-action-link">Időpont foglalás</a>
        </p>
    </div>
</main>

<?php include("includes/footer.php"); ?>