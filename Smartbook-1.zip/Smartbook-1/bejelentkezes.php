<?php
include("includes/header.php");
include("kapcsolat.php");

$hibaUzenet = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $bejelentkezoEmail = trim($_POST["email"]);
    $bejelentkezoJelszo = $_POST["jelszo_hash"];

    if ($bejelentkezoEmail == "" || $bejelentkezoJelszo == "") {
        $hibaUzenet = "Minden mezőt ki kell tölteni.";
    } else {
        $lekerdezes = "
            SELECT id, teljes_nev, jelszo_hash
            FROM felhasznalok
            WHERE email = '" . $adatbazisKapcsolat->real_escape_string($bejelentkezoEmail) . "'
        ";

        $eredmeny = $adatbazisKapcsolat->query($lekerdezes);

        if ($eredmeny && $eredmeny->num_rows == 1) {
            $talaltFelhasznalo = $eredmeny->fetch_assoc();

            $adatbazisbanLevoJelszo = $talaltFelhasznalo["jelszo_hash"];

            if (password_verify($bejelentkezoJelszo, $adatbazisbanLevoJelszo)) {
                // Egységes session kulcsok, amiket a többi oldal is használ
                $_SESSION["user_id"] = $talaltFelhasznalo["id"];
                $_SESSION["teljes_nev"] = $talaltFelhasznalo["teljes_nev"];

                // Egyszerű admin jogosultság: az admin@smartbook.hu e-mail admin
                $_SESSION["is_admin"] = ($bejelentkezoEmail === "admin@smartbook.hu");

                if (!empty($_SESSION["is_admin"])) {
                    header("Location: admin.php");
                } else {
                    header("Location: foglalas.php");
                }
                exit();
            } else {
                $hibaUzenet = "Hibás jelszó.";
            }
        } else {
            $hibaUzenet = "Nincs ilyen e‑mail címmel regisztrált felhasználó.";
        }
    }
}
?>

<main>
    <div class="card">
        <h2>Bejelentkezés</h2>

        <?php if ($hibaUzenet != ""): ?>
            <p class="error"><?php echo $hibaUzenet; ?></p>
        <?php endif; ?>

        <form method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="jelszo_hash" placeholder="Jelszó" required>
            <button type="submit">Bejelentkezés</button>
        </form>
    </div>
</main>