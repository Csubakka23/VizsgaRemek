<hr>
<footer>
    <p>© 2026 SmartBook</p>
</footer>
</body>
</html>