<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>SmartBook</title>
    <link rel="stylesheet" href="/Smartbook/css/style.css">
</head>
<body>
    
<nav>
<?php if(isset($_SESSION["user_id"])): ?>
    <div class="account-badge">
        👤 <a href="dashboard.php">
            <?php echo htmlspecialchars($_SESSION["teljes_nev"] ?? ($_SESSION["email"] ?? "Fiók")); ?>
        </a>
    </div>
<?php endif; ?>
    <a href="index.php">Főoldal</a>

    <?php if(isset($_SESSION["user_id"])): ?>
        <?php if (!empty($_SESSION["is_admin"])): ?>
            <a href="admin.php">Admin</a>
        <?php endif; ?>
        <a href="dashboard.php">Dashboard</a>
        <a href="foglalasaim.php">Foglalásaim</a>
        <a href="kijelentkezes.php">Kijelentkezés</a>
    <?php else: ?>
        <a href="bejelentkezes.php">Bejelentkezés</a>
        <a href="regisztracio.php">Regisztráció</a>
    <?php endif; ?>
    
</nav>