<?php include("includes/header.php"); ?>

<main>
    <div class="card">
        <section class="home-header">
            <h1>Keresse és foglalja le a legjobb szolgáltatásokat egy helyen!</h1>
            <p>Keressen rá a kívánt szolgáltatásra és találja meg a legjobb szakembereket pillanatok alatt.</p>
        </section>

        <form class="home-search" action="foglalas.php" method="get">
            <input type="text" name="kategoria" placeholder="Szolgáltatás vagy kategória (pl. fodrász, fogászat)" autocomplete="off">
            <input type="text" name="lokacio" placeholder="Lokáció (város, kerület)" autocomplete="off">
            <button type="submit">Fedezze fel most</button>
        </form>

        <section class="home-categories">
            <div class="home-category-card">
                <div class="home-category-icon">✂️</div>
                <div class="home-category-label">Fodrászat</div>
            </div>
            <div class="home-category-card">
                <div class="home-category-icon">🦷</div>
                <div class="home-category-label">Fogászat</div>
            </div>
            <div class="home-category-card">
                <div class="home-category-icon">💄</div>
                <div class="home-category-label">Kozmetika</div>
            </div>
            <div class="home-category-card">
                <div class="home-category-icon">🚗</div>
                <div class="home-category-label">Autószerviz</div>
            </div>
            <div class="home-category-card">
                <div class="home-category-icon">🏋️</div>
                <div class="home-category-label">Sport &amp; fitnesz</div>
            </div>
            <div class="home-category-card">
                <div class="home-category-icon">🐾</div>
                <div class="home-category-label">Állatorvos</div>
            </div>
        </section>

        <section class="home-footer-links">
            <a href="#">Szolgáltatások</a>
            <a href="#">Rólunk</a>
            <a href="#">Gyakori kérdések</a>
            <a href="#">Kapcsolat</a>
        </section>
    </div>
</main>

<?php include("includes/footer.php"); ?>