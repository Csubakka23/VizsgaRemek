<?php
include("includes/header.php");
include("kapcsolat.php");

$hibaUzenet = "";
$sikerUzenet = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $teljesNev = trim($_POST["teljes_nev"]);
    $felhasznaloEmail = trim($_POST["email"]);
    $felhasznaloJelszo = $_POST["jelszo_hash"];

    if ($teljesNev == "" || $felhasznaloEmail == "" || $felhasznaloJelszo == "") {
        $hibaUzenet = "Minden mezőt ki kell tölteni.";
    } else {

        // Ellenőrizzük, hogy létezik-e már ez az email
        $stmt = $adatbazisKapcsolat->prepare(
            "SELECT id FROM felhasznalok WHERE email = ?"
        );
        $stmt->bind_param("s", $felhasznaloEmail);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $hibaUzenet = "Ezzel az e-mail címmel már regisztráltak.";
        } else {

            $titkositottJelszo = password_hash($felhasznaloJelszo, PASSWORD_DEFAULT);

            $insertStmt = $adatbazisKapcsolat->prepare(
                "INSERT INTO felhasznalok (teljes_nev, email, jelszo_hash) VALUES (?, ?, ?)"
            );

            $insertStmt->bind_param("sss", $teljesNev, $felhasznaloEmail, $titkositottJelszo);

            if ($insertStmt->execute()) {
                $sikerUzenet = "Sikeres regisztráció! Most már bejelentkezhetsz.";
            } else {
                $hibaUzenet = "Hiba történt a regisztráció során: " . $insertStmt->error;
            }

            $insertStmt->close();
        }

        $stmt->close();
    }
}
?>

<main>
    <div class="card">
        <h2>Regisztráció</h2>

        <?php if ($hibaUzenet != ""): ?>
            <p class="error"><?php echo $hibaUzenet; ?></p>
        <?php endif; ?>

        <?php if ($sikerUzenet != ""): ?>
            <p class="success"><?php echo $sikerUzenet; ?></p>
        <?php endif; ?>

        <form method="POST">
            <input type="text" name="teljes_nev" placeholder="Teljes név" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="jelszo_hash" placeholder="Jelszó" required>
            <button type="submit">Regisztráció</button>
        </form>
    </div>
</main>