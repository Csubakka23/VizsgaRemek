<?php
// Adatbázis kapcsolat létrehozása
$adatbazisKapcsolat = new mysqli("localhost", "root", "", "idopontfoglalas");

// Ha hiba van a kapcsolódáskor, álljon le az oldal és írja ki a hibát
if ($adatbazisKapcsolat->connect_error) {
    die("Adatbázis hiba: " . $adatbazisKapcsolat->connect_error);
}
?>