<?php
session_start();
require_once "kapcsolat.php";
include "includes/header.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: bejelentkezes.php");
    exit;
}

$userId = (int)$_SESSION["user_id"];
$uzenet = "";

// Lemondás kezelése
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["lemond_foglalas_id"])) {
    $foglalasId = (int)$_POST["lemond_foglalas_id"];

    // Ellenőrzés: ez a foglalás a bejelentkezett useré?
    $chk = $adatbazisKapcsolat->query("
        SELECT id, idopont_id
        FROM foglalasok
        WHERE id = $foglalasId AND user_id = $userId
        LIMIT 1
    ");

    if ($chk && $chk->num_rows === 1) {
        $row = $chk->fetch_assoc();
        $idopontId = (int)$row["idopont_id"];

        try {
            $adatbazisKapcsolat->begin_transaction();

            // Foglalás törlése
            $adatbazisKapcsolat->query("
                DELETE FROM foglalasok
                WHERE id = $foglalasId AND user_id = $userId
                LIMIT 1
            ");

            // Időpont felszabadítása
            $adatbazisKapcsolat->query("
                UPDATE idopontok
                SET foglalt = 0
                WHERE id = $idopontId
                LIMIT 1
            ");

            $adatbazisKapcsolat->commit();
            $uzenet = "✅ A foglalás lemondva, az időpont felszabadítva.";
        } catch (Throwable $e) {
            $adatbazisKapcsolat->rollback();
            $uzenet = "❌ Hiba történt a lemondás közben: " . htmlspecialchars($e->getMessage());
        }
    } else {
        $uzenet = "❌ Ezt a foglalást nem találom (vagy nem a tiéd).";
    }
}

// Foglalások lekérése
// (dolgozo_id és szalon/dolgozó join akkor is működik, ha nálad NULL lehet valamelyik)
$foglalasok = $adatbazisKapcsolat->query("
    SELECT
        f.id AS foglalas_id,
        i.id AS idopont_id,
        i.datum,
        i.ido,
        s.nev AS szalon_nev,
        d.nev AS dolgozo_nev
    FROM foglalasok f
    INNER JOIN idopontok i ON i.id = f.idopont_id
    LEFT JOIN szalonok s ON s.id = i.szalon_id
    LEFT JOIN dolgozok d ON d.id = i.dolgozo_id
    WHERE f.user_id = $userId
    ORDER BY i.datum DESC, i.ido DESC
");
?>

<main>
<div class="card bookings-card">
    <h2>Foglalásaim</h2>

    <?php if (!empty($uzenet)): ?>
        <div class="alert"><?php echo $uzenet; ?></div>
    <?php endif; ?>

    <?php if (!$foglalasok || $foglalasok->num_rows === 0): ?>
        <p>Még nincs foglalásod.</p>
    <?php else: ?>
        <table class="bookings-table">
            <thead>
                <tr>
                    <th>Időpont</th>
                    <th>Szalon</th>
                    <th>Dolgozó</th>
                    <th>Művelet</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($f = $foglalasok->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($f["datum"] . " " . $f["ido"]); ?></td>
                        <td><?php echo htmlspecialchars($f["szalon_nev"] ?? "-"); ?></td>
                        <td><?php echo htmlspecialchars($f["dolgozo_nev"] ?? "-"); ?></td>
                        <td>
                            <form method="POST" onsubmit="return confirm('Biztosan lemondod ezt az időpontot?');">
                                <input type="hidden" name="lemond_foglalas_id" value="<?php echo (int)$f["foglalas_id"]; ?>">
                                <button type="submit" class="btn-cancel">Lemondás</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php include "includes/footer.php"; ?>
</div>
</main>