<?php
include("includes/header.php");
include("kapcsolat.php");

// Csak admin érheti el az oldalt
if (empty($_SESSION["is_admin"])) {
    header("Location: bejelentkezes.php");
    exit();
}

$uzenet = "";

// Új szakterület felvétele
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["action"]) && $_POST["action"] === "uj_szakterulet") {
    $szakNev = trim($_POST["szakterulet_nev"] ?? "");

    if ($szakNev !== "") {
        $nevEsc = $adatbazisKapcsolat->real_escape_string($szakNev);
        $sql = "INSERT INTO szakteruletek (nev) VALUES ('$nevEsc')";
        if ($adatbazisKapcsolat->query($sql)) {
            $uzenet = "Új szakterület sikeresen hozzáadva.";
        } else {
            $uzenet = "Hiba a szakterület mentésekor: " . $adatbazisKapcsolat->error;
        }
    } else {
        $uzenet = "A szakterület neve nem lehet üres.";
    }
}

// Új szolgáltatás felvétele
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["action"]) && $_POST["action"] === "uj_szolgaltatas") {
    $nev = trim($_POST["szolg_nev"] ?? "");
    $idotartam = (int)($_POST["szolg_idotartam"] ?? 30);
    $ar = (int)($_POST["szolg_ar"] ?? 0);

    if ($nev !== "") {
        $sql = "
            INSERT INTO szolgaltatasok (nev, idotartam_perc, ar)
            VALUES (
                '" . $adatbazisKapcsolat->real_escape_string($nev) . "',
                $idotartam,
                $ar
            )
        ";
        if ($adatbazisKapcsolat->query($sql)) {
            $uzenet = "Új szolgáltatás sikeresen hozzáadva.";
        } else {
            $uzenet = "Hiba a szolgáltatás mentésekor: " . $adatbazisKapcsolat->error;
        }
    } else {
        $uzenet = "A szolgáltatás neve nem lehet üres.";
    }
}

// Új dolgozó felvétele
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["action"]) && $_POST["action"] === "uj_dolgozo") {
    $nev = trim($_POST["dolgozo_nev"] ?? "");
    $szakteruletId = (int)($_POST["dolgozo_szakterulet_id"] ?? 0);
    $szakteruletNev = "";

    if ($szakteruletId > 0) {
        $talalt = $adatbazisKapcsolat->query("SELECT nev FROM szakteruletek WHERE id = $szakteruletId");
        if ($talalt && $talalt->num_rows === 1) {
            $adat = $talalt->fetch_assoc();
            $szakteruletNev = $adat["nev"];
        }
    }

    if ($nev !== "") {
        $sql = "
            INSERT INTO dolgozok (nev, szakterulet)
            VALUES (
                '" . $adatbazisKapcsolat->real_escape_string($nev) . "',
                '" . $adatbazisKapcsolat->real_escape_string($szakteruletNev) . "'
            )
        ";
        if ($adatbazisKapcsolat->query($sql)) {
            $uzenet = "Új dolgozó sikeresen hozzáadva.";
        } else {
            $uzenet = "Hiba a dolgozó mentésekor: " . $adatbazisKapcsolat->error;
        }
    } else {
        $uzenet = "A dolgozó neve nem lehet üres.";
    }
}

// Meglévő dolgozó szakterületének módosítása
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["action"]) && $_POST["action"] === "modosit_dolgozo_szakterulet") {
    $dolgozoId = (int)($_POST["dolgozo_id"] ?? 0);
    $ujSzakteruletId = (int)($_POST["uj_szakterulet_id"] ?? 0);

    if ($dolgozoId > 0 && $ujSzakteruletId > 0) {
        $talalt = $adatbazisKapcsolat->query("SELECT nev FROM szakteruletek WHERE id = $ujSzakteruletId");
        if ($talalt && $talalt->num_rows === 1) {
            $adat = $talalt->fetch_assoc();
            $szakteruletNev = $adatbazisKapcsolat->real_escape_string($adat["nev"]);

            $sql = "UPDATE dolgozok SET szakterulet = '$szakteruletNev' WHERE id = $dolgozoId";
            if ($adatbazisKapcsolat->query($sql)) {
                $uzenet = "Dolgozó szakterülete frissítve.";
            } else {
                $uzenet = "Hiba a dolgozó frissítésekor: " . $adatbazisKapcsolat->error;
            }
        }
    }
}

// Új szabad időpont felvétele
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["action"]) && $_POST["action"] === "uj_idopont") {
    $datum = trim($_POST["idopont_datum"] ?? "");
    $ido = trim($_POST["idopont_ido"] ?? "");

    if ($datum !== "" && $ido !== "") {
        $sql = "
            INSERT INTO idopontok (datum, ido, foglalt)
            VALUES (
                '" . $adatbazisKapcsolat->real_escape_string($datum) . "',
                '" . $adatbazisKapcsolat->real_escape_string($ido) . "',
                0
            )
        ";
        if ($adatbazisKapcsolat->query($sql)) {
            $uzenet = "Új szabad időpont sikeresen hozzáadva.";
        } else {
            $uzenet = "Hiba az időpont mentésekor: " . $adatbazisKapcsolat->error;
        }
    } else {
        $uzenet = "A dátum és az idő nem lehet üres.";
    }
}

// Szakterületek listája (új dolgozóhoz és módosításhoz)
$szakteruletekLista = [];
$szakteruletekEredmeny = $adatbazisKapcsolat->query("SELECT id, nev FROM szakteruletek ORDER BY nev");
if ($szakteruletekEredmeny) {
    while ($row = $szakteruletekEredmeny->fetch_assoc()) {
        $szakteruletekLista[] = $row;
    }
}

// Listák betöltése
$szolgaltatasok = $adatbazisKapcsolat->query("SELECT * FROM szolgaltatasok ORDER BY nev");
$dolgozok = $adatbazisKapcsolat->query("SELECT * FROM dolgozok ORDER BY nev");
$idopontok = $adatbazisKapcsolat->query("SELECT * FROM idopontok ORDER BY datum, ido");
?>

<main>
    <div class="card">
        <h2>Admin felület</h2>
        <p>Szolgáltatások, dolgozók és szabad időpontok kezelése.</p>

        <?php if ($uzenet !== ""): ?>
            <p class="success"><?php echo htmlspecialchars($uzenet); ?></p>
        <?php endif; ?>

        <section style="margin-top: 10px; margin-bottom: 24px;">
            <h3>Új szakterület</h3>
            <form method="post" class="admin-form">
                <input type="hidden" name="action" value="uj_szakterulet">
                <input type="text" name="szakterulet_nev" placeholder="Szakterület neve (pl. Fodrász)" required>
                <button type="submit">Szakterület hozzáadása</button>
            </form>
        </section>

        <section style="margin-bottom: 24px;">
            <h3>Új szolgáltatás</h3>
            <form method="post" class="admin-form">
                <input type="hidden" name="action" value="uj_szolgaltatas">
                <input type="text" name="szolg_nev" placeholder="Szolgáltatás neve" required>
                <input type="number" name="szolg_idotartam" placeholder="Időtartam (perc)" min="10" max="240" value="30" required>
                <input type="number" name="szolg_ar" placeholder="Ár (Ft)" min="0" step="500" value="6000" required>
                <button type="submit">Szolgáltatás hozzáadása</button>
            </form>
        </section>

        <section style="margin-bottom: 24px;">
            <h3>Új dolgozó</h3>
            <form method="post" class="admin-form">
                <input type="hidden" name="action" value="uj_dolgozo">
                <input type="text" name="dolgozo_nev" placeholder="Dolgozó neve" required>
                <select name="dolgozo_szakterulet_id" required>
                    <option value="">Válassz szakterületet</option>
                    <?php foreach ($szakteruletekLista as $szak): ?>
                        <option value="<?php echo (int)$szak["id"]; ?>">
                            <?php echo htmlspecialchars($szak["nev"]); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit">Dolgozó hozzáadása</button>
            </form>
        </section>

        <section style="margin-bottom: 24px;">
            <h3>Új szabad időpont</h3>
            <form method="post" class="admin-form">
                <input type="hidden" name="action" value="uj_idopont">
                <input type="date" name="idopont_datum" required>
                <input type="time" name="idopont_ido" required>
                <button type="submit">Időpont hozzáadása</button>
            </form>
        </section>

        <section class="admin-lists">
            <div>
                <h3>Szolgáltatások</h3>
                <?php if ($szolgaltatasok && $szolgaltatasok->num_rows > 0): ?>
                    <ul>
                        <?php while ($s = $szolgaltatasok->fetch_assoc()): ?>
                            <li>
                                <?php echo htmlspecialchars($s["nev"]); ?>
                                (<?php echo (int)$s["idotartam_perc"]; ?> perc, <?php echo (int)$s["ar"]; ?> Ft)
                            </li>
                        <?php endwhile; ?>
                    </ul>
                <?php else: ?>
                    <p>Még nincs rögzített szolgáltatás.</p>
                <?php endif; ?>
            </div>

            <div>
                <h3>Dolgozók</h3>
                <?php if ($dolgozok && $dolgozok->num_rows > 0): ?>
                    <ul>
                        <?php while ($d = $dolgozok->fetch_assoc()): ?>
                            <li>
                                <?php echo htmlspecialchars($d["nev"]); ?>
                                <?php if (!empty($d["szakterulet"])): ?>
                                    – <?php echo htmlspecialchars($d["szakterulet"]); ?>
                                <?php endif; ?>

                                <form method="post" class="admin-inline-form">
                                    <input type="hidden" name="action" value="modosit_dolgozo_szakterulet">
                                    <input type="hidden" name="dolgozo_id" value="<?php echo (int)$d["id"]; ?>">
                                    <select name="uj_szakterulet_id">
                                        <option value="0">Szakterület módosítása…</option>
                                        <?php foreach ($szakteruletekLista as $szak): ?>
                                            <option value="<?php echo (int)$szak["id"]; ?>" <?php echo ($d["szakterulet"] === $szak["nev"]) ? "selected" : ""; ?>>
                                                <?php echo htmlspecialchars($szak["nev"]); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit">Mentés</button>
                                </form>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                <?php else: ?>
                    <p>Még nincs rögzített dolgozó.</p>
                <?php endif; ?>
            </div>

            <div>
                <h3>Időpontok</h3>
                <?php if ($idopontok && $idopontok->num_rows > 0): ?>
                    <ul>
                        <?php while ($i = $idopontok->fetch_assoc()): ?>
                            <li>
                                <?php echo htmlspecialchars($i["datum"] . " " . $i["ido"]); ?>
                                <?php if (!empty($i["foglalt"]) && (int)$i["foglalt"] === 1): ?>
                                    – foglalt
                                <?php else: ?>
                                    – szabad
                                <?php endif; ?>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                <?php else: ?>
                    <p>Még nincs rögzített időpont.</p>
                <?php endif; ?>
            </div>
        </section>
    </div>
</main>

<?php include("includes/footer.php"); ?>

