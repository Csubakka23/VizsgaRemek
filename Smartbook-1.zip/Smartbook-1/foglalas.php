<?php
include("includes/header.php");
include("kapcsolat.php");

// Csak bejelentkezett felhasználó foglalhat
if (!isset($_SESSION["user_id"])) {
    header("Location: bejelentkezes.php");
    exit();
}

// Szakterület és szalon szűrők (GET paraméterek)
$valasztottSzakteruletId = isset($_GET["szakterulet"]) ? (int)$_GET["szakterulet"] : 0;
$valasztottSzalonId = isset($_GET["szalon"]) ? (int)$_GET["szalon"] : 0;

// Ha még nincs egyetlen időpont sem, létrehozunk pár alap időpontot (fodrász szalonhoz)
$ellenorzes = $adatbazisKapcsolat->query("SELECT COUNT(*) AS db FROM idopontok");
if ($ellenorzes) {
    $sor = $ellenorzes->fetch_assoc();
    if ((int)$sor["db"] === 0) {
        $ma = date("Y-m-d");
        $holnap = date("Y-m-d", strtotime("+1 day"));
        $tulnap = date("Y-m-d", strtotime("+2 days"));

        // alapértelmezett szalon: 1-es ID (pl. első fodrász szalon)
        $adatbazisKapcsolat->query("
            INSERT INTO idopontok (datum, ido, foglalt, szalon_id) VALUES
            ('$ma', '10:00:00', 0, 1),
            ('$ma', '11:00:00', 0, 1),
            ('$holnap', '14:00:00', 0, 1),
            ('$holnap', '15:30:00', 0, 1),
            ('$tulnap', '09:00:00', 0, 1)
        ");
    }
}

$uzenet = "";

// Foglalás mentése (ha van kattintás)
if (isset($_GET["foglal"])) {

    $idopont_id = (int)$_GET["foglal"];
    $user_id = (int)$_SESSION["user_id"];

    try {
        $adatbazisKapcsolat->begin_transaction();

        // 1) Csak akkor foglaljuk le az időpontot, ha még szabad (foglalt=0)
        $stmtUpdate = $adatbazisKapcsolat->prepare("
            UPDATE idopontok
            SET foglalt = 1
            WHERE id = ? AND foglalt = 0
        ");
        $stmtUpdate->bind_param("i", $idopont_id);
        $stmtUpdate->execute();

        if ($stmtUpdate->affected_rows !== 1) {
            // Már lefoglalták
            $adatbazisKapcsolat->rollback();
            $uzenet = "❌ Ezt az időpontot már lefoglalták, válassz másikat.";
        } else {
            // 2) Foglalás beszúrása (DB unique index is védi)
            $stmtInsert = $adatbazisKapcsolat->prepare("
                INSERT INTO foglalasok (user_id, idopont_id)
                VALUES (?, ?)
            ");
            $stmtInsert->bind_param("ii", $user_id, $idopont_id);
            $stmtInsert->execute();

            $adatbazisKapcsolat->commit();
            $uzenet = "✅ Sikeres foglalás!";
        }
    } catch (mysqli_sql_exception $e) {
        // Ha pl. a UNIQUE miatt mégis ütközés van, visszagörgetjük
        if ($adatbazisKapcsolat->errno) {
            $adatbazisKapcsolat->rollback();
        }
        $uzenet = "❌ Nem sikerült lefoglalni (valószínűleg már elvitték).";
    }
}

// Szakterületek és szalonok betöltése a szűrőkhöz
$szakteruletek = $adatbazisKapcsolat->query("SELECT id, nev FROM szakteruletek ORDER BY nev");
$szalonok = null;
if ($valasztottSzakteruletId > 0) {
    $szalonok = $adatbazisKapcsolat->query("SELECT id, nev FROM szalonok WHERE szakterulet_id = $valasztottSzakteruletId ORDER BY nev");
}

// Szalon részletekhez: dolgozók lekérése (ha van kiválasztott szalon)
$dolgozok = null;
if ($valasztottSzalonId > 0) {
    $dolgozok = $adatbazisKapcsolat->query("
        SELECT id, nev, rovid_bemutatas
        FROM dolgozok
        WHERE aktiv = 1 AND szalon_id = $valasztottSzalonId
        ORDER BY nev
    ");
}
?>

<main>
    <div class="card">
        <h2>Időpont foglalás</h2>

        <?php if ($uzenet !== ""): ?>
            <p class="success"><?php echo $uzenet; ?></p>
        <?php endif; ?>

        <form method="get" class="booking-filters">
            <select name="szakterulet">
                <option value="0">Összes szakterület</option>
                <?php if ($szakteruletek): ?>
                    <?php while ($szak = $szakteruletek->fetch_assoc()): ?>
                        <option value="<?php echo (int)$szak["id"]; ?>" <?php echo $valasztottSzakteruletId === (int)$szak["id"] ? "selected" : ""; ?>>
                            <?php echo htmlspecialchars($szak["nev"]); ?>
                        </option>
                    <?php endwhile; ?>
                <?php endif; ?>
            </select>

            <select name="szalon">
                <option value="0">Összes szalon</option>
                <?php if ($szalonok): ?>
                    <?php while ($sz = $szalonok->fetch_assoc()): ?>
                        <option value="<?php echo (int)$sz["id"]; ?>" <?php echo $valasztottSzalonId === (int)$sz["id"] ? "selected" : ""; ?>>
                            <?php echo htmlspecialchars($sz["nev"]); ?>
                        </option>
                    <?php endwhile; ?>
                <?php endif; ?>
            </select>

            <button type="submit">Szűrés</button>
        </form>

        <div class="booking-list">

    <?php if ($valasztottSzakteruletId <= 0): ?>
        <p>Válassz egy szakterületet, és megjelennek a hozzá tartozó szalonok.</p>

    <?php elseif ($valasztottSzalonId <= 0): ?>
        <h3>Választható szalonok</h3>

        <?php if (!$szalonok || $szalonok->num_rows === 0): ?>
            <p>Nincs találat erre a szakterületre.</p>
        <?php else: ?>
            <div class="salon-grid">
                <?php while ($sz = $szalonok->fetch_assoc()): ?>
                    <a class="salon-card"
                       href="foglalas.php?szakterulet=<?php echo $valasztottSzakteruletId; ?>&szalon=<?php echo (int)$sz['id']; ?>">
                        <div class="salon-name"><?php echo htmlspecialchars($sz["nev"]); ?></div>
                        <div class="salon-hint">Kattints: dolgozók és időpontok</div>
                    </a>
                <?php endwhile; ?>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <div class="salon-back">
            <a href="foglalas.php?szakterulet=<?php echo $valasztottSzakteruletId; ?>">← Vissza a szalonokhoz</a>
        </div>

        <h3>Dolgozók és szabad időpontok</h3>

        <?php if (!$dolgozok || $dolgozok->num_rows === 0): ?>
            <p>Ehhez a szalonhoz még nincs dolgozó.</p>
        <?php else: ?>
            <?php while ($d = $dolgozok->fetch_assoc()): ?>
                <div class="worker-card">
                    <div class="worker-name"><?php echo htmlspecialchars($d["nev"]); ?></div>
                    <?php if (!empty($d["rovid_bemutatas"])): ?>
                        <div class="worker-bio"><?php echo htmlspecialchars($d["rovid_bemutatas"]); ?></div>
                    <?php endif; ?>

                    <?php
                        $did = (int)$d["id"];
                        $idop = $adatbazisKapcsolat->query("
                            SELECT id, datum, ido
                            FROM idopontok
                            WHERE foglalt = 0
                              AND szalon_id = $valasztottSzalonId
                              AND dolgozo_id = $did
                            ORDER BY datum, ido
                        ");
                    ?>

                    <?php if (!$idop || $idop->num_rows === 0): ?>
                        <div class="worker-empty">Nincs szabad időpont.</div>
                    <?php else: ?>
                        <div class="times-grid">
                            <?php while ($t = $idop->fetch_assoc()): ?>
                                <div class="time-pill">
                                    <div class="time-text">
                                        <?php echo htmlspecialchars($t["datum"] . " " . $t["ido"]); ?>
                                    </div>
                                    <a class="time-book"
                                       href="foglalas.php?foglal=<?php echo (int)$t['id']; ?>&szakterulet=<?php echo $valasztottSzakteruletId; ?>&szalon=<?php echo $valasztottSzalonId; ?>">
                                        Foglalás
                                    </a>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>

    <?php endif; ?>

</div>
</main>

<?php include("includes/footer.php"); ?>